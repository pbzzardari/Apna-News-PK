
import React, { useState, useEffect, useCallback } from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import Header from './components/Header';
import Hero from './components/Hero';
import NewsTicker from './components/NewsTicker';
import PakistanMap from './components/PakistanMap';
import NewsGrid from './components/NewsGrid';
import ChatBot from './components/ChatBot';
import AIAnchor from './components/AIAnchor';
import Footer from './components/Footer';
import ArticleModal from './components/ArticleModal';
import AdminPanel from './components/AdminPanel';
import ArchiveGenerator from './components/ArchiveGenerator';
import { newsService } from './newsService';
import { NewsArticle } from './types';

const App: React.FC = () => {
  const [topNews, setTopNews] = useState<NewsArticle[]>([]);
  const [breakingNews, setBreakingNews] = useState<NewsArticle[]>([]);
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(() => {
    const saved = localStorage.getItem('theme');
    return saved === 'dark';
  });

  const loadData = useCallback(async () => {
    const news = await newsService.fetchTopHeadlines();
    setTopNews(news.slice(0, 8));
    setBreakingNews(news.slice(0, 5));
  }, []);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 600000); // 10 mins
    return () => clearInterval(interval);
  }, [loadData]);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  return (
    <HashRouter>
      <div className={`min-h-screen flex flex-col transition-colors duration-500`}>
        <Header 
          isDarkMode={isDarkMode} 
          toggleTheme={() => setIsDarkMode(!isDarkMode)} 
        />
        
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={
              <>
                <NewsTicker news={breakingNews} />
                <Hero article={topNews[0]} onReadMore={setSelectedArticle} />
                
                <section className="container mx-auto px-4 py-12 grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2">
                    <h2 className="text-3xl font-extrabold mb-8 flex items-center gap-2">
                      <span className="w-2 h-8 bg-green-600 rounded-full"></span>
                      Latest Updates
                    </h2>
                    <NewsGrid news={topNews.slice(1)} onSelect={setSelectedArticle} />
                  </div>
                  
                  <aside className="space-y-8">
                    {/* Interactive Map Section */}
                    <div className="glass p-6 rounded-3xl shadow-xl overflow-hidden">
                      <h3 className="text-xl font-bold mb-4">Interactive Pakistan</h3>
                      <div className="w-full h-80 flex items-center justify-center">
                        <PakistanMap onProvinceSelect={(prov) => console.log('Prov selected:', prov)} />
                      </div>
                    </div>

                    {/* Offline Archive Generator */}
                    <ArchiveGenerator news={topNews} />
                    
                    {/* AI Anchor Section */}
                    <div className="bg-gradient-to-br from-green-600 to-green-900 p-6 rounded-3xl text-white shadow-2xl relative overflow-hidden">
                      <div className="relative z-10">
                        <h3 className="text-2xl font-bold mb-2">AI Anchor Mode</h3>
                        <p className="text-sm opacity-90 mb-4">Get your daily summary read by our futuristic AI presenter.</p>
                        <button className="bg-white text-green-900 px-6 py-2 rounded-full font-bold hover:scale-105 transition-transform">
                          Enable Voice
                        </button>
                      </div>
                      <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-12 translate-x-12 blur-2xl"></div>
                    </div>
                  </aside>
                </section>
              </>
            } />
            <Route path="/admin" element={<AdminPanel />} />
          </Routes>
        </main>

        <Footer />
        
        {/* Persistent AI Features */}
        <AIAnchor />
        <ChatBot />

        {/* Modal for Article Reading */}
        {selectedArticle && (
          <ArticleModal 
            article={selectedArticle} 
            onClose={() => setSelectedArticle(null)} 
          />
        )}
      </div>
    </HashRouter>
  );
};

export default App;
