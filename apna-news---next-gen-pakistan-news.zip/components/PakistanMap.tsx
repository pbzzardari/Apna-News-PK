
import React from 'react';
import { motion } from 'framer-motion';
import { Province } from '../types';

interface PakistanMapProps {
  onProvinceSelect: (province: Province) => void;
}

const PakistanMap: React.FC<PakistanMapProps> = ({ onProvinceSelect }) => {
  // Simplified SVG paths for Pakistan provinces for visual representation
  const provinces = [
    { id: 'punjab', name: Province.PUNJAB, path: "M50,40 L70,30 L80,50 L70,70 L50,60 Z", color: "#0a7d3b" },
    { id: 'sindh', name: Province.SINDH, path: "M40,70 L60,80 L50,95 L30,90 Z", color: "#064b23" },
    { id: 'kpk', name: Province.KPK, path: "M30,20 L50,15 L60,30 L40,40 Z", color: "#10b981" },
    { id: 'balochistan', name: Province.BALOCHISTAN, path: "M10,50 L40,60 L30,85 L5,80 Z", color: "#059669" },
    { id: 'gb', name: Province.GB, path: "M60,10 L80,5 L90,15 L70,25 Z", color: "#34d399" },
    { id: 'ajk', name: Province.AJK, path: "M80,30 L95,35 L90,45 L75,40 Z", color: "#047857" },
  ];

  return (
    <div className="relative w-full h-full group">
      <svg viewBox="0 0 100 100" className="w-full h-full drop-shadow-2xl filter brightness-90 contrast-110">
        {provinces.map((prov) => (
          <motion.path
            key={prov.id}
            d={prov.path}
            fill={prov.color}
            stroke="white"
            strokeWidth="0.5"
            whileHover={{ 
              scale: 1.05, 
              fill: '#f59e0b',
              transition: { duration: 0.2 } 
            }}
            onClick={() => onProvinceSelect(prov.name)}
            className="cursor-pointer transition-all"
          >
            <title>{prov.name}</title>
          </motion.path>
        ))}
        {/* Animated Hotspots */}
        <circle cx="65" cy="55" r="1.5" fill="#f87171">
          <animate attributeName="r" from="1" to="3" dur="1s" repeatCount="indefinite" />
          <animate attributeName="opacity" from="1" to="0" dur="1s" repeatCount="indefinite" />
        </circle>
        <circle cx="45" cy="85" r="1.5" fill="#f87171">
          <animate attributeName="r" from="1" to="3" dur="1.5s" repeatCount="indefinite" />
          <animate attributeName="opacity" from="1" to="0" dur="1.5s" repeatCount="indefinite" />
        </circle>
      </svg>
      <div className="absolute bottom-2 left-2 flex flex-col gap-1 text-[8px] font-bold text-slate-500 uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
        <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-red-400"></span> Live Events</span>
        <span className="flex items-center gap-1"><span className="w-2 h-2 rounded-full bg-green-600"></span> News density</span>
      </div>
    </div>
  );
};

export default PakistanMap;
