
import React from 'react';
import { BarChart, Activity, Users, Globe, Database, ShieldAlert } from 'lucide-react';

const AdminPanel: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex items-center justify-between mb-12">
        <div>
          <h1 className="text-3xl font-black mb-2">System Control Center</h1>
          <p className="text-slate-500 font-medium">Monitor real-time engagement and AI service health.</p>
        </div>
        <div className="bg-green-600/10 text-green-600 px-4 py-2 rounded-full text-xs font-black flex items-center gap-2">
          <Activity size={16} className="animate-pulse" />
          SYSTEMS NOMINAL
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {[
          { label: 'Active Sessions', val: '14,202', icon: Users, color: 'text-blue-500' },
          { label: 'AI Summaries', val: '8,421/day', icon: Activity, color: 'text-purple-500' },
          { label: 'API Queries', val: '1.2M', icon: Database, color: 'text-green-500' },
          { label: 'Uptime', val: '99.98%', icon: Globe, color: 'text-amber-500' },
        ].map((stat, i) => (
          <div key={i} className="glass p-6 rounded-3xl border border-slate-100 dark:border-white/5 shadow-sm">
            <div className={`p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 w-fit mb-4 ${stat.color}`}>
              <stat.icon size={24} />
            </div>
            <p className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-1">{stat.label}</p>
            <h3 className="text-2xl font-black">{stat.val}</h3>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="glass p-8 rounded-[2.5rem] min-h-[400px]">
          <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
            <BarChart size={24} className="text-green-600" />
            Regional Hotspots
          </h3>
          <div className="space-y-6">
            {[
              { label: 'Punjab', val: 65, color: 'bg-green-500' },
              { label: 'Sindh', val: 45, color: 'bg-green-600' },
              { label: 'KPK', val: 30, color: 'bg-emerald-500' },
              { label: 'Balochistan', val: 15, color: 'bg-teal-600' },
            ].map((reg, i) => (
              <div key={i}>
                <div className="flex justify-between text-xs font-bold uppercase mb-2">
                  <span>{reg.label}</span>
                  <span>{reg.val}%</span>
                </div>
                <div className="h-2 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                  <div className={`h-full ${reg.color} rounded-full`} style={{ width: `${reg.val}%` }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="glass p-8 rounded-[2.5rem]">
          <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
            <ShieldAlert size={24} className="text-amber-500" />
            AI Moderation Log
          </h3>
          <div className="space-y-4">
            {[
              'Fact-check triggered: Political speech verifcation',
              'Sentiment filter: High negative variance in comments',
              'New trend detected: #PakistanEconomy growth signals',
              'Bias warning: Source #N-342 showing deviation',
            ].map((log, i) => (
              <div key={i} className="flex gap-4 p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/50 text-sm font-medium border border-slate-100 dark:border-white/5">
                <span className="text-slate-400 text-xs font-mono">{new Date().toLocaleTimeString()}</span>
                <span>{log}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;
