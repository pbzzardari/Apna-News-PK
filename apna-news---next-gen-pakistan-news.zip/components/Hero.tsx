
import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Play, TrendingUp } from 'lucide-react';
import { NewsArticle } from '../types';

interface HeroProps {
  article?: NewsArticle;
  onReadMore: (article: NewsArticle) => void;
}

const Hero: React.FC<HeroProps> = ({ article, onReadMore }) => {
  if (!article) return <div className="h-96 w-full animate-pulse bg-slate-200 dark:bg-slate-800 rounded-3xl" />;

  return (
    <section className="relative h-[600px] w-full overflow-hidden group">
      {/* Background Image with Parallax effect simulation */}
      <div 
        className="absolute inset-0 bg-cover bg-center transition-transform duration-1000 scale-105 group-hover:scale-110"
        style={{ backgroundImage: `url(${article.image_url || 'https://picsum.photos/1920/1080'})` }}
      />
      
      {/* Overlays */}
      <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/40 to-transparent" />
      <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900/20 to-transparent" />

      {/* Content */}
      <div className="absolute inset-0 flex items-end">
        <div className="container mx-auto px-4 pb-16">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-3xl"
          >
            <div className="flex items-center gap-3 mb-6">
              <span className="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded tracking-widest uppercase">
                BREAKING
              </span>
              <span className="flex items-center gap-1 text-green-400 text-xs font-bold">
                <TrendingUp size={14} />
                TOP STORY OF THE DAY
              </span>
            </div>
            
            <h1 className="text-4xl md:text-6xl font-black text-white mb-6 leading-tight drop-shadow-2xl">
              {article.title}
            </h1>
            
            <p className="text-lg text-slate-200 mb-8 line-clamp-2 max-w-2xl opacity-90 leading-relaxed">
              {article.description}
            </p>
            
            <div className="flex flex-wrap gap-4">
              <button 
                onClick={() => onReadMore(article)}
                className="group/btn flex items-center gap-2 px-8 py-4 bg-green-600 hover:bg-green-700 text-white rounded-2xl font-bold transition-all shadow-xl shadow-green-600/30"
              >
                READ FULL STORY
                <ArrowRight size={20} className="group-hover/btn:translate-x-2 transition-transform" />
              </button>
              
              <button className="flex items-center gap-2 px-8 py-4 bg-white/10 hover:bg-white/20 backdrop-blur-md text-white rounded-2xl font-bold border border-white/20 transition-all">
                <Play size={20} />
                WATCH REPORT
              </button>
            </div>
          </motion.div>
        </div>
      </div>
      
      {/* Decorative pulse element */}
      <div className="absolute bottom-10 right-10 flex items-center gap-2 text-white/50 text-xs font-mono">
        <div className="w-2 h-2 rounded-full bg-red-500 animate-ping"></div>
        LIVE NEWS FEED
      </div>
    </section>
  );
};

export default Hero;
