
import React from 'react';
import { motion, useMotionValue, useTransform } from 'framer-motion';
import { Clock, Tag } from 'lucide-react';
import { NewsArticle } from '../types';

interface NewsCardProps {
  article: NewsArticle;
  onSelect: (article: NewsArticle) => void;
}

const NewsCard: React.FC<NewsCardProps> = ({ article, onSelect }) => {
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  const rotateX = useTransform(y, [-100, 100], [10, -10]);
  const rotateY = useTransform(x, [-100, 100], [-10, 10]);

  function handleMouseMove(event: React.MouseEvent) {
    const rect = event.currentTarget.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;
    const mouseX = event.clientX - rect.left;
    const mouseY = event.clientY - rect.top;
    x.set(mouseX - width / 2);
    y.set(mouseY - height / 2);
  }

  function handleMouseLeave() {
    x.set(0);
    y.set(0);
  }

  return (
    <motion.div
      style={{ rotateX, rotateY, perspective: 1000 }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onClick={() => onSelect(article)}
      className="glass rounded-3xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 cursor-pointer flex flex-col h-full group"
    >
      <div className="relative h-48 overflow-hidden">
        <img 
          src={article.image_url || 'https://picsum.photos/400/300?sig=' + Math.random()} 
          alt={article.title}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <div className="absolute top-4 left-4 bg-green-600 text-white text-[10px] font-bold px-2 py-1 rounded">
          {article.category?.[0]?.toUpperCase() || 'NEWS'}
        </div>
      </div>
      
      <div className="p-5 flex flex-col flex-grow">
        <div className="flex items-center gap-3 text-[10px] font-bold text-slate-400 mb-3">
          <span className="flex items-center gap-1 uppercase">
            <Tag size={12} className="text-green-600" />
            {article.source_id}
          </span>
          <span className="flex items-center gap-1">
            <Clock size={12} />
            {new Date(article.pubDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
        
        <h3 className="text-lg font-extrabold mb-3 line-clamp-2 leading-tight group-hover:text-green-600 transition-colors">
          {article.title}
        </h3>
        
        <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-3 leading-relaxed flex-grow">
          {article.description}
        </p>
      </div>
    </motion.div>
  );
};

export default NewsCard;
