
import React from 'react';
import { LOGO, COLORS } from '../constants';
import { Facebook, Twitter, Instagram, Youtube, Mail, MapPin, Phone } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-950 text-white pt-20 pb-10 overflow-hidden relative">
      <div className="container mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-20">
          <div>
            <div className="mb-8 scale-125 origin-left">
              <LOGO.Gradient />
            </div>
            <p className="text-slate-400 text-sm leading-relaxed mb-8">
              APNA NEWS is Pakistan's leading digital news platform, bringing you the most accurate, real-time updates from across the nation powered by state-of-the-art Gemini AI.
            </p>
            <div className="flex gap-4">
              {[Facebook, Twitter, Instagram, Youtube].map((Icon, idx) => (
                <a key={idx} href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-green-600 transition-colors">
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-8">Quick Navigation</h4>
            <ul className="space-y-4 text-slate-400 text-sm font-medium">
              <li><a href="#" className="hover:text-green-500 transition-colors">National News</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Global Reports</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Politics & Policy</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Business Today</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Lifestyle & Health</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-8">Support & Trust</h4>
            <ul className="space-y-4 text-slate-400 text-sm font-medium">
              <li><a href="#" className="hover:text-green-500 transition-colors">Editorial Guidelines</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Fact-Check Policy</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Privacy & Terms</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Corrections</a></li>
              <li><a href="#" className="hover:text-green-500 transition-colors">Report a Bug</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-bold mb-8">Headquarters</h4>
            <ul className="space-y-4 text-slate-400 text-sm font-medium">
              <li className="flex items-start gap-3">
                <MapPin size={18} className="text-green-500 mt-1 flex-shrink-0" />
                <span>Media Town, Phase II, Islamabad, Pakistan</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone size={18} className="text-green-500 flex-shrink-0" />
                <span>+92 (051) 111-APNA-N</span>
              </li>
              <li className="flex items-center gap-3">
                <Mail size={18} className="text-green-500 flex-shrink-0" />
                <span>contact@apnanews.pk</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/5 pt-10 flex flex-col md:flex-row items-center justify-between gap-6 text-slate-500 text-xs font-bold uppercase tracking-widest">
          <p>© 2025 APNA NEWS - AWAZ PAKISTAN KI. ALL RIGHTS RESERVED.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors">Sitemap</a>
            <a href="#" className="hover:text-white transition-colors">Cookies</a>
            <a href="#" className="hover:text-white transition-colors">Feedback</a>
          </div>
        </div>
      </div>

      {/* Background Decorative element */}
      <div className="absolute top-0 right-0 w-[800px] h-[800px] bg-green-900/10 rounded-full blur-[120px] translate-x-1/2 -translate-y-1/2 pointer-events-none"></div>
    </footer>
  );
};

export default Footer;
