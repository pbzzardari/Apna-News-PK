
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Play, Pause, X, Radio } from 'lucide-react';

const AIAnchor: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);

  return (
    <div className="fixed bottom-24 right-6 z-[85]">
      <AnimatePresence>
        {isActive && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 20 }}
            className="mb-4 bg-gradient-to-br from-slate-900 to-slate-800 p-4 rounded-3xl shadow-2xl border border-white/10 w-64 overflow-hidden"
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-[10px] font-black text-green-400 flex items-center gap-1">
                <Radio size={12} className="animate-pulse" />
                VIRTUAL ANCHOR
              </span>
              <button onClick={() => setIsActive(false)}>
                <X size={16} className="text-white/50" />
              </button>
            </div>
            
            <div className="relative w-full aspect-square rounded-2xl bg-slate-950 overflow-hidden mb-4 group">
              <img 
                src="https://picsum.photos/400/400?anchor" 
                className={`w-full h-full object-cover grayscale transition-all duration-1000 ${isPlaying ? 'grayscale-0 scale-105' : 'blur-sm'}`}
                alt="AI Anchor"
              />
              <div className="absolute inset-0 bg-green-600/20 mix-blend-overlay"></div>
              {isPlaying && (
                <div className="absolute bottom-4 left-4 right-4 flex justify-center gap-1 h-8 items-end">
                  {[...Array(8)].map((_, i) => (
                    <div 
                      key={i} 
                      className="w-1 bg-green-400 rounded-full animate-wave"
                      style={{ animationDelay: `${i * 0.1}s`, height: `${Math.random() * 100}%` }}
                    ></div>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-3">
              <p className="text-white text-xs font-medium leading-relaxed opacity-90">
                {isPlaying 
                  ? "Reading top headlines for Islamabad, Karachi, and Lahore..." 
                  : "Listen to the 60-second Pakistan News Summary."}
              </p>
              
              <button 
                onClick={() => setIsPlaying(!isPlaying)}
                className="w-full flex items-center justify-center gap-2 py-3 bg-white text-slate-900 rounded-xl font-bold transition-all hover:bg-green-400 active:scale-95"
              >
                {isPlaying ? <Pause size={18} /> : <Play size={18} />}
                {isPlaying ? 'PAUSE NEWS' : 'PLAY NOW'}
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {!isActive && (
        <motion.button
          whileHover={{ scale: 1.1 }}
          onClick={() => setIsActive(true)}
          className="px-6 py-3 bg-slate-900 text-white rounded-full flex items-center gap-3 shadow-2xl shadow-black/40 border border-white/10"
        >
          <div className="relative">
            <img src="https://picsum.photos/50/50?avatar" className="w-8 h-8 rounded-full border border-green-500" alt="Avatar" />
            <span className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-500 border-2 border-slate-900 rounded-full"></span>
          </div>
          <span className="font-bold text-sm">AI Anchor Mode</span>
        </motion.button>
      )}
      
      <style>{`
        @keyframes wave {
          0%, 100% { height: 10%; }
          50% { height: 100%; }
        }
        .animate-wave {
          animation: wave 1s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
};

export default AIAnchor;
