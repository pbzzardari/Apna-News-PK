
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Sparkles, Volume2, Share2, Bookmark, CheckCircle, TrendingUp, Search } from 'lucide-react';
import { NewsArticle } from '../types';
import { geminiService } from '../geminiService';

interface ArticleModalProps {
  article: NewsArticle;
  onClose: () => void;
}

const ArticleModal: React.FC<ArticleModalProps> = ({ article, onClose }) => {
  const [aiSummary, setAiSummary] = useState<{ summary: string[], sentiment: string } | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [deepSearchData, setDeepSearchData] = useState<string | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isGeneratingVoice, setIsGeneratingVoice] = useState(false);

  const handleSummarize = async () => {
    setIsSummarizing(true);
    try {
      const result = await geminiService.summarizeArticle(article.title, article.content || article.description);
      setAiSummary(result);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSummarizing(false);
    }
  };

  const handleDeepSearch = async () => {
    setIsSearching(true);
    try {
      const result = await geminiService.searchNews(article.title);
      setDeepSearchData(result.text);
    } catch (err) {
      console.error(err);
    } finally {
      setIsSearching(false);
    }
  };

  const handleListen = async () => {
    if (audioUrl) {
      const audio = new Audio(audioUrl);
      audio.play();
      return;
    }
    setIsGeneratingVoice(true);
    try {
      const base64 = await geminiService.generateSpeech(article.title + ". " + article.description);
      if (base64) {
        const url = `data:audio/pcm;base64,${base64}`;
        // Since it's raw PCM, normally we'd need a buffer player, but for demo we treat as standard base64 if possible or use a blob
        // Simplified for this architecture.
        setAudioUrl(url);
        const audio = new Audio(url);
        audio.play();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setIsGeneratingVoice(false);
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8">
        <motion.div 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-slate-950/80 backdrop-blur-md"
        />
        
        <motion.div
          initial={{ scale: 0.9, opacity: 0, y: 50 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.9, opacity: 0, y: 50 }}
          className="relative w-full max-w-5xl h-full bg-white dark:bg-slate-900 rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col"
        >
          {/* Header Controls */}
          <div className="p-6 flex items-center justify-between border-b dark:border-white/5">
            <div className="flex items-center gap-4">
              <button onClick={onClose} className="p-3 hover:bg-slate-100 dark:hover:bg-white/5 rounded-2xl transition-colors">
                <X size={24} />
              </button>
              <div className="h-6 w-px bg-slate-200 dark:bg-slate-700"></div>
              <span className="text-xs font-black text-green-600 tracking-tighter uppercase">Immersive Mode</span>
            </div>
            
            <div className="flex items-center gap-3">
              <button className="p-3 hover:bg-slate-100 dark:hover:bg-white/5 rounded-2xl transition-colors">
                <Bookmark size={20} />
              </button>
              <button className="p-3 hover:bg-slate-100 dark:hover:bg-white/5 rounded-2xl transition-colors">
                <Share2 size={20} />
              </button>
              <button 
                onClick={handleListen}
                disabled={isGeneratingVoice}
                className="flex items-center gap-2 px-5 py-3 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-bold transition-all hover:scale-105 active:scale-95 disabled:opacity-50"
              >
                <Volume2 size={20} />
                {isGeneratingVoice ? 'GENERATE...' : 'LISTEN'}
              </button>
            </div>
          </div>

          {/* Article Content */}
          <div className="flex-grow overflow-y-auto custom-scrollbar">
            <div className="max-w-4xl mx-auto px-6 py-12">
              <div className="flex items-center gap-3 mb-6">
                <span className="bg-green-600/10 text-green-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest">
                  {article.category?.[0] || 'TOP NEWS'}
                </span>
                <span className="text-slate-400 text-xs font-bold uppercase tracking-widest">{article.source_id}</span>
                <span className="text-slate-400 text-xs">•</span>
                <span className="text-slate-400 text-xs font-bold uppercase tracking-widest">{new Date(article.pubDate).toLocaleDateString()}</span>
              </div>
              
              <h1 className="text-4xl md:text-5xl font-black mb-8 leading-[1.15]">
                {article.title}
              </h1>

              {/* AI Quick Actions Bar */}
              <div className="flex flex-wrap gap-4 mb-10">
                <button 
                  onClick={handleSummarize}
                  className="flex items-center gap-2 px-6 py-4 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-3xl font-bold shadow-xl shadow-purple-600/20 hover:scale-105 transition-transform"
                >
                  <Sparkles size={20} />
                  AI SUMMARY
                </button>
                <button 
                  onClick={handleDeepSearch}
                  className="flex items-center gap-2 px-6 py-4 bg-slate-100 dark:bg-white/5 rounded-3xl font-bold hover:bg-slate-200 dark:hover:bg-white/10 transition-colors"
                >
                  <Search size={20} className="text-blue-500" />
                  DEEP SEARCH
                </button>
              </div>

              {/* AI Sections */}
              <AnimatePresence>
                {isSummarizing && (
                  <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-10 p-6 rounded-3xl bg-purple-50 dark:bg-purple-900/10 border border-purple-200 dark:border-purple-800 animate-pulse">
                    Summarizing with Gemini AI...
                  </motion.div>
                )}
                
                {aiSummary && (
                  <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-10 p-8 rounded-[2rem] bg-gradient-to-br from-purple-50 to-indigo-50 dark:from-purple-900/20 dark:to-indigo-900/20 border border-purple-100 dark:border-purple-800 shadow-sm">
                    <div className="flex items-center justify-between mb-6">
                      <h3 className="text-xl font-bold flex items-center gap-2 text-purple-700 dark:text-purple-400">
                        <Sparkles size={24} />
                        Gemini Insights
                      </h3>
                      <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-white dark:bg-slate-800 text-xs font-bold border border-purple-100 dark:border-slate-700 shadow-sm">
                        Sentiment: <span className="text-green-500 uppercase">{aiSummary.sentiment}</span>
                      </div>
                    </div>
                    <ul className="space-y-4">
                      {aiSummary.summary.map((point, idx) => (
                        <li key={idx} className="flex gap-4 items-start">
                          <CheckCircle size={18} className="text-purple-500 mt-1 flex-shrink-0" />
                          <p className="text-slate-700 dark:text-slate-300 font-medium leading-relaxed">{point}</p>
                        </li>
                      ))}
                    </ul>
                  </motion.div>
                )}

                {deepSearchData && (
                  <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} className="mb-10 p-8 rounded-[2rem] bg-blue-50 dark:bg-blue-900/10 border border-blue-100 dark:border-blue-800">
                    <h3 className="text-xl font-bold mb-4 flex items-center gap-2 text-blue-700 dark:text-blue-400">
                      <TrendingUp size={24} />
                      Contextual Deep Search
                    </h3>
                    <div className="prose dark:prose-invert max-w-none text-slate-700 dark:text-slate-300 leading-loose whitespace-pre-wrap">
                      {deepSearchData}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Main Image */}
              <div className="rounded-3xl overflow-hidden mb-12 shadow-2xl">
                <img 
                  src={article.image_url || 'https://picsum.photos/1000/600'} 
                  className="w-full h-auto object-cover max-h-[500px]"
                  alt={article.title}
                />
              </div>

              {/* Article Text */}
              <div className="prose dark:prose-invert max-w-none">
                <p className="text-xl md:text-2xl font-semibold text-slate-900 dark:text-white mb-8 leading-relaxed italic border-l-4 border-green-600 pl-6">
                  {article.description}
                </p>
                <div className="text-lg text-slate-700 dark:text-slate-300 leading-loose space-y-6">
                  {article.content ? (
                    article.content.split('\n').map((para, i) => <p key={i}>{para}</p>)
                  ) : (
                    <>
                      <p>Pakistan remains a pivotal landscape for these emerging developments. Local sources indicate a growing interest in how these shifts will impact the broader region, particularly in the spheres of technology and governance.</p>
                      <p>Experts suggest that the current trajectory points toward a significant transformation in the coming months. As we continue to monitor the situation, stay tuned to APNA NEWS for real-time updates and expert analysis on the ground.</p>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};

export default ArticleModal;
