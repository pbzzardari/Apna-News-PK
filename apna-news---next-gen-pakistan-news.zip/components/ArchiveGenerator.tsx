
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Download, Package, CheckCircle2, Loader2, FileJson, ShieldCheck } from 'lucide-react';
import JSZip from 'jszip';
import { NewsArticle } from '../types';

interface ArchiveGeneratorProps {
  news: NewsArticle[];
}

const ArchiveGenerator: React.FC<ArchiveGeneratorProps> = ({ news }) => {
  const [status, setStatus] = useState<'idle' | 'generating' | 'ready'>('idle');
  const [progress, setProgress] = useState(0);

  const generateArchive = async () => {
    setStatus('generating');
    setProgress(10);
    const zip = new JSZip();

    // 1. Create Data JSON
    zip.file("news_data.json", JSON.stringify(news, null, 2));
    setProgress(30);

    // 2. Create Offline HTML Viewer
    const htmlContent = `
<!DOCTYPE html>
<html>
<head>
    <title>APNA NEWS - Offline Archive</title>
    <style>
        body { font-family: sans-serif; background: #0f172a; color: white; padding: 40px; }
        .card { background: #1e293b; padding: 20px; border-radius: 12px; margin-bottom: 20px; border: 1px solid #334155; }
        h1 { color: #10b981; }
        .meta { color: #94a3b8; font-size: 12px; }
    </style>
</head>
<body>
    <h1>APNA NEWS: Daily Offline Digest</h1>
    <p>Generated on: ${new Date().toLocaleString()}</p>
    <hr/>
    ${news.map(n => `
        <div class="card">
            <h2>${n.title}</h2>
            <div class="meta">${n.source_id} | ${n.pubDate}</div>
            <p>${n.description}</p>
            <a href="${n.link}" style="color: #10b981;">Original Source</a>
        </div>
    `).join('')}
</body>
</html>`;
    zip.file("index.html", htmlContent);
    setProgress(60);

    // 3. Add Readme
    zip.file("README.txt", "APNA NEWS PORTABLE ARCHIVE\n\nThis package contains a standalone snapshot of the top stories in Pakistan. Open index.html to view.");
    setProgress(80);

    // 4. Generate Blob
    const content = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(content);
    
    const link = document.createElement("a");
    link.href = url;
    link.download = `ApnaNews_Archive_${new Date().toISOString().split('T')[0]}.zip`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    setProgress(100);
    setStatus('ready');
    
    setTimeout(() => {
      setStatus('idle');
      setProgress(0);
    }, 3000);
  };

  return (
    <div className="glass p-6 rounded-[2rem] border border-green-500/20 shadow-2xl relative overflow-hidden group">
      <div className="relative z-10">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-green-600 rounded-xl text-white">
            <Package size={20} />
          </div>
          <h3 className="font-bold text-lg">Portable Archive</h3>
        </div>
        
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 leading-relaxed">
          Heading to a low-connectivity area? Download a compressed **ZIP package** of today's top stories for full offline access.
        </p>

        <AnimatePresence mode="wait">
          {status === 'idle' && (
            <motion.button
              key="idle"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={generateArchive}
              className="w-full flex items-center justify-center gap-2 py-4 bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-2xl font-black text-sm hover:scale-[1.02] transition-transform active:scale-95 shadow-xl shadow-black/10"
            >
              <Download size={18} />
              GENERATE ZIP BUNDLE
            </motion.button>
          )}

          {status === 'generating' && (
            <motion.div
              key="generating"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-3"
            >
              <div className="flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-green-600">
                <span className="flex items-center gap-2">
                  <Loader2 size={12} className="animate-spin" />
                  Bundling Assets...
                </span>
                <span>{progress}%</span>
              </div>
              <div className="h-1.5 w-full bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <motion.div 
                  initial={{ width: 0 }}
                  animate={{ width: `${progress}%` }}
                  className="h-full bg-green-500"
                />
              </div>
            </motion.div>
          )}

          {status === 'ready' && (
            <motion.div
              key="ready"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center justify-center gap-2 py-4 text-green-600 font-bold text-sm bg-green-50 dark:bg-green-900/20 rounded-2xl border border-green-200 dark:border-green-800"
            >
              <CheckCircle2 size={18} />
              DOWNLOAD STARTED
            </motion.div>
          )}
        </AnimatePresence>

        <div className="mt-6 pt-6 border-t dark:border-white/5 flex items-center justify-between">
          <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400">
            <ShieldCheck size={14} className="text-green-600" />
            SECURE EXPORT
          </div>
          <div className="flex items-center gap-2 text-[10px] font-bold text-slate-400">
            <FileJson size={14} />
            JSON READY
          </div>
        </div>
      </div>
      
      {/* Background Glow */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-green-500/5 rounded-full blur-3xl -translate-y-12 translate-x-12 group-hover:bg-green-500/10 transition-colors"></div>
    </div>
  );
};

export default ArchiveGenerator;
