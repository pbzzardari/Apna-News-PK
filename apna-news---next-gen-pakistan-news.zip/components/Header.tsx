
import React from 'react';
import { Link } from 'react-router-dom';
import { Sun, Moon, Search, User, Globe, Menu } from 'lucide-react';
import { LOGO, COLORS } from '../constants';

interface HeaderProps {
  isDarkMode: boolean;
  toggleTheme: () => void;
}

const Header: React.FC<HeaderProps> = ({ isDarkMode, toggleTheme }) => {
  return (
    <header className="sticky top-0 z-50 glass shadow-sm transition-all duration-300">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        {/* Left: Branding */}
        <div className="flex items-center gap-8">
          <Link to="/" className="hover:opacity-80 transition-opacity">
            <LOGO.Gradient />
          </Link>
          <nav className="hidden md:flex items-center gap-6 font-semibold text-sm">
            <Link to="/" className="hover:text-green-600 transition-colors">POLITICS</Link>
            <Link to="/" className="hover:text-green-600 transition-colors">ECONOMY</Link>
            <Link to="/" className="hover:text-green-600 transition-colors">SPORTS</Link>
            <Link to="/" className="hover:text-green-600 transition-colors">TECH</Link>
            <Link to="/admin" className="text-amber-500 hover:text-amber-600 transition-colors flex items-center gap-1">
              PRO <span className="bg-amber-500/10 px-1 rounded text-[10px]">ADMIN</span>
            </Link>
          </nav>
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-4">
          <button className="p-2 hover:bg-black/5 dark:hover:bg-white/5 rounded-full transition-colors">
            <Search size={20} />
          </button>
          
          <div className="h-6 w-px bg-slate-200 dark:bg-slate-700 mx-1"></div>
          
          <button 
            onClick={toggleTheme}
            className="p-2 hover:bg-black/5 dark:hover:bg-white/5 rounded-full transition-colors"
          >
            {isDarkMode ? <Sun size={20} className="text-amber-400" /> : <Moon size={20} />}
          </button>

          <button className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-full text-sm font-bold shadow-lg shadow-green-600/20 hover:bg-green-700 transition-all hover:scale-105 active:scale-95">
            <User size={16} />
            <span className="hidden sm:inline">LOGIN</span>
          </button>

          <button className="md:hidden p-2">
            <Menu size={24} />
          </button>
        </div>
      </div>
    </header>
  );
};

export default Header;
