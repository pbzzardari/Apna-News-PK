
import React from 'react';
import { NewsArticle } from '../types';

interface NewsTickerProps {
  news: NewsArticle[];
}

const NewsTicker: React.FC<NewsTickerProps> = ({ news }) => {
  return (
    <div className="bg-slate-900 text-white py-2 overflow-hidden border-b border-white/5">
      <div className="container mx-auto px-4 flex items-center gap-4">
        <div className="flex-shrink-0 flex items-center gap-2 bg-red-600 px-3 py-1 rounded text-[10px] font-black uppercase tracking-tighter">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-white opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-white"></span>
          </span>
          Breaking
        </div>
        <div className="relative flex-grow overflow-hidden h-6">
          <div className="whitespace-nowrap flex items-center animate-ticker hover:pause-animation cursor-pointer">
            {news.map((item, idx) => (
              <span key={item.article_id || idx} className="mx-8 text-sm font-medium opacity-80 hover:opacity-100 transition-opacity">
                {item.title}
              </span>
            ))}
          </div>
        </div>
      </div>
      <style>{`
        @keyframes ticker {
          0% { transform: translateX(100%); }
          100% { transform: translateX(-100%); }
        }
        .animate-ticker {
          animation: ticker 30s linear infinite;
        }
        .hover\\:pause-animation:hover {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  );
};

export default NewsTicker;
