
import React from 'react';
import NewsCard from './NewsCard';
import { NewsArticle } from '../types';

interface NewsGridProps {
  news: NewsArticle[];
  onSelect: (article: NewsArticle) => void;
}

const NewsGrid: React.FC<NewsGridProps> = ({ news, onSelect }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {news.map((article, idx) => (
        <NewsCard 
          key={article.article_id || idx} 
          article={article} 
          onSelect={onSelect} 
        />
      ))}
      {news.length === 0 && (
        <div className="col-span-full py-20 text-center opacity-50">
          <p>No news found. Check your connection or API key.</p>
        </div>
      )}
    </div>
  );
};

export default NewsGrid;
