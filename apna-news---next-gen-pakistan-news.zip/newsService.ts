
import { NewsResponse, NewsArticle } from './types';
import { NEWS_API_KEY } from './constants';

export const newsService = {
  async fetchTopHeadlines(country = 'pk'): Promise<NewsArticle[]> {
    try {
      const response = await fetch(`https://newsdata.io/api/1/news?apikey=${NEWS_API_KEY}&country=${country}&language=en`);
      const data: NewsResponse = await response.json();
      return data.results || [];
    } catch (error) {
      console.error("Error fetching news:", error);
      return [];
    }
  },

  async fetchNewsByCategory(category: string, country = 'pk'): Promise<NewsArticle[]> {
    try {
      const response = await fetch(`https://newsdata.io/api/1/news?apikey=${NEWS_API_KEY}&country=${country}&category=${category}&language=en`);
      const data: NewsResponse = await response.json();
      return data.results || [];
    } catch (error) {
      console.error(`Error fetching ${category} news:`, error);
      return [];
    }
  },

  async fetchNewsByQuery(query: string): Promise<NewsArticle[]> {
    try {
      const response = await fetch(`https://newsdata.io/api/1/news?apikey=${NEWS_API_KEY}&q=${encodeURIComponent(query)}&language=en`);
      const data: NewsResponse = await response.json();
      return data.results || [];
    } catch (error) {
      console.error(`Error searching news for ${query}:`, error);
      return [];
    }
  }
};
