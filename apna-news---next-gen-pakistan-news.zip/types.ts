
export interface NewsArticle {
  article_id: string;
  title: string;
  link: string;
  description: string;
  content: string;
  pubDate: string;
  image_url: string;
  source_id: string;
  category: string[];
  country: string[];
  language: string;
  sentiment?: 'positive' | 'negative' | 'neutral';
  summary?: string;
}

export interface NewsResponse {
  status: string;
  totalResults: number;
  results: NewsArticle[];
}

export enum Province {
  PUNJAB = 'Punjab',
  SINDH = 'Sindh',
  KPK = 'Khyber Pakhtunkhwa',
  BALOCHISTAN = 'Balochistan',
  GB = 'Gilgit-Baltistan',
  AJK = 'Azad Jammu and Kashmir'
}

export interface UserPreferences {
  theme: 'light' | 'dark';
  language: 'en' | 'ur';
  savedArticles: string[];
}
