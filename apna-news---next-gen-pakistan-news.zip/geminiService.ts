
import { GoogleGenAI, Type, Modality } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const geminiService = {
  // Deep Search Grounding
  async searchNews(query: string) {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Search for detailed context regarding: ${query}. Focus on Pakistani perspective.`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });
    return {
      text: response.text,
      sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || []
    };
  },

  // AI Summarization
  async summarizeArticle(title: string, content: string) {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Summarize the following Pakistani news article in 5 bullet points and identify its sentiment (positive, neutral, negative): 
      Title: ${title}
      Content: ${content}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            summary: { type: Type.ARRAY, items: { type: Type.STRING } },
            sentiment: { type: Type.STRING, description: "One of: positive, negative, neutral" },
            key_entities: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["summary", "sentiment"]
        }
      }
    });
    return JSON.parse(response.text || '{}');
  },

  // Audio Transcription (Simulated via microphone stream elsewhere, this handles processing if needed)
  async transcribeAudio(base64Audio: string) {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          { inlineData: { mimeType: "audio/wav", data: base64Audio } },
          { text: "Transcribe this audio. If it is Urdu, provide both Urdu and English translation." }
        ]
      }
    });
    return response.text;
  },

  // TTS Generation
  async generateSpeech(text: string, voiceName: string = 'Kore') {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `Say clearly in a professional news anchor tone: ${text}` }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName },
          },
        },
      },
    });
    return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  },

  // Chat with Gemini Pro
  async chatWithGemini(message: string, history: any[] = []) {
    const chat = ai.chats.create({
      model: 'gemini-3-pro-preview',
      config: {
        systemInstruction: "You are 'Apna News AI', a helpful and authoritative Pakistani news assistant. You have deep knowledge of Pakistan's history, politics, and current events.",
      },
    });
    const response = await chat.sendMessage({ message });
    return response.text;
  }
};
