
import React from 'react';

export const COLORS = {
  PAKISTAN_GREEN: '#0a7d3b',
  PAKISTAN_GREEN_DARK: '#064b23',
  PAKISTAN_GREEN_LIGHT: '#10b981',
  DARK_GRAY: '#1f2937',
  ACCENT_GOLD: '#f59e0b',
};

export const LOGO = {
  Flat: () => (
    <svg width="180" height="40" viewBox="0 0 180 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect width="180" height="40" rx="8" fill={COLORS.PAKISTAN_GREEN} />
      <text x="50%" y="50%" dominantBaseline="middle" textAnchor="middle" fill="white" fontSize="20" fontWeight="800" fontFamily="Montserrat">APNA NEWS</text>
    </svg>
  ),
  Gradient: () => (
    <svg width="180" height="40" viewBox="0 0 180 40" fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="logoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={COLORS.PAKISTAN_GREEN} />
          <stop offset="100%" stopColor={COLORS.PAKISTAN_GREEN_DARK} />
        </linearGradient>
      </defs>
      <rect width="180" height="40" rx="8" fill="url(#logoGrad)" />
      <text x="50%" y="50%" dominantBaseline="middle" textAnchor="middle" fill="white" fontSize="20" fontWeight="800" fontFamily="Montserrat">APNA NEWS</text>
    </svg>
  )
};

export const NEWS_API_KEY = 'pub_2476651d5d1e4592810168ad34db67f9';
